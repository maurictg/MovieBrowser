package com.avans.movieapp.interfaces;


/**
 * Implement this callback with a lambda to use it
 */
public interface ICallback {
    void callback(Object data, boolean success);
}
